package com.adminSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminSystem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
