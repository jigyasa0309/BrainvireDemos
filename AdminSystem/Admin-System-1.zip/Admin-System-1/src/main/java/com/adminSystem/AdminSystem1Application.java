package com.adminSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(AdminSystem1Application.class, args);
	}

}
